package com.mycustomproject.listener;

public interface ViewTextListener {
    void onTextSuccess(Object object0);
    void onTextSuccess(Object object0,Object object1);
    void onTextSuccess(Object object0,Object object1,Object object2);
    void onTextSuccess(Object object0,Object object1,Object object2,Object object3);
    void onTextSuccess(Object object0,Object object1,Object object2,Object object3,Object object4);
    void onTextSuccess(Object object0,Object object1,Object object2,Object object3,Object object4,Object object5);
}
