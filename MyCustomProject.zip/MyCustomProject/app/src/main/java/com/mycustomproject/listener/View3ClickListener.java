package com.mycustomproject.listener;

public  interface View3ClickListener  {
     void onCliick(Object object0,Object object1,Object object2);
}
