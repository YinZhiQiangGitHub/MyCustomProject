package com.mycustomproject.listener;

public abstract   interface View1ClickListener {
     void onCliick(int object0);
}
