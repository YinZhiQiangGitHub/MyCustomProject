package com.mycustomproject.http;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.mycustomproject.R;
import com.mycustomproject.main.baseUtil.BaseActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainHttpTestActivity extends BaseActivity {

    @Override
    public int getLayoutResId() {
        return R.layout.activity_main_http_test;
    }

    @Override
    public void initBindingID() {

    }

    @Override
    public void initView() {

    }



}
