package com.mycustomproject.listener;

public  interface View2ClickListener {
     void onCliick(Object object0,Object object1);
}
