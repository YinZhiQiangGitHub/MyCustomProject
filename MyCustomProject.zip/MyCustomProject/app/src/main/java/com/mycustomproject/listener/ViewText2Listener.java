package com.mycustomproject.listener;

public interface ViewText2Listener extends ViewTextListener {
    @Override
    void onTextSuccess(Object object0, Object object1);
}