package com.mycustomproject.listener;

public  interface View4ClickListener extends ViewClickListener{
     void onCliick(Object object0,Object object1,Object object2,Object object3);
}
