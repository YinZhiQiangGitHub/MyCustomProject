package com.mycustomproject.listener;

public interface ViewClickListener {
    void onCliick(Object object0);
    void onCliick(Object object0,Object object1);
    void onCliick(Object object0,Object object1,Object object2);
    void onCliick(Object object0,Object object1,Object object2,Object object3);
    void onCliick(Object object0,Object object1,Object object2,Object object3,Object object4);
    void onCliick(Object object0,Object object1,Object object2,Object object3,Object object4,Object object5);
}
