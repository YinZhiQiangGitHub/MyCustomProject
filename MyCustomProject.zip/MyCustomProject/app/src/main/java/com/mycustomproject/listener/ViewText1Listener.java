package com.mycustomproject.listener;

public interface ViewText1Listener extends ViewTextListener {
    void onTextSuccess(Object object0);
}
